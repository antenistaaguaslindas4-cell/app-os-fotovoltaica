# OS Fotovoltaica — APK via GitHub Actions

Projeto Android que empacota a versão web/PWA da OS Fotovoltaica em um aplicativo instalável.

## Gerar o APK
1. Envie os arquivos deste projeto para o repositório GitHub.
2. Abra a aba Actions.
3. Selecione **Build Android APK**.
4. Execute **Run workflow** ou faça um push na branch principal.
5. Ao terminar, abra a execução e baixe o artefato **OS-Fotovoltaica-APK**.

O workflow usa Java 17 e Gradle 8.10.2.
