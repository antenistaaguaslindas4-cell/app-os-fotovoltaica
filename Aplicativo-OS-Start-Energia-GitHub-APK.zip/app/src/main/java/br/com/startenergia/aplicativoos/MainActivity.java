package br.com.startenergia.aplicativoos;

import android.content.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.*;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    WebView web;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);
        web.setBackgroundColor(0xfff3f6fa);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(this), "Android");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    public static class Bridge {
        Context c;
        Bridge(Context c){this.c=c;}

        @JavascriptInterface public void shareWhatsApp(String text){
            Intent i=new Intent(Intent.ACTION_SEND);
            i.setType("text/plain"); i.setPackage("com.whatsapp");
            i.putExtra(Intent.EXTRA_TEXT, android.text.Html.fromHtml(text.replace("%0A","<br>")).toString());
            try{c.startActivity(i);}catch(Exception e){
                Intent j=new Intent(Intent.ACTION_SEND);j.setType("text/plain");j.putExtra(Intent.EXTRA_TEXT,text);
                c.startActivity(Intent.createChooser(j,"Compartilhar OS"));
            }
        }

        @JavascriptInterface public void generatePDF(String json){
            try{
                org.json.JSONObject d=new org.json.JSONObject(json);
                String cliente=d.optString("cliente","cliente");
                String numero=d.optString("numero","sem-numero");
                PdfDocument pdf=new PdfDocument();
                PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,1).create();
                PdfDocument.Page p=pdf.startPage(pi);
                android.graphics.Canvas cv=p.getCanvas();
                android.graphics.Paint paint=new android.graphics.Paint();
                paint.setColor(0xff0b1220);paint.setTextSize(20);paint.setFakeBoldText(true);
                cv.drawText("START ENERGIA",40,50,paint);
                paint.setFakeBoldText(false);paint.setTextSize(11);
                int y=80;
                String[] lines={
                    "ORDEM DE SERVIÇO",
                    "OS: "+numero,
                    "Data: "+d.optString("data"),
                    "Cliente: "+cliente,
                    "Telefone: "+d.optString("telefone"),
                    "Endereço: "+d.optString("endereco"),
                    "Serviço: "+d.optString("tipo"),
                    "Inversor/Microinversor: "+d.optString("inversor"),
                    "",
                    "DESCRIÇÃO",
                    d.optString("descricao"),
                    "",
                    "CHECKLIST",
                    d.optJSONArray("checks")!=null?d.optJSONArray("checks").toString().replace("[","").replace("]","").replace("\"",""):"",
                    "",
                    "MATERIAIS",
                    d.optJSONArray("mats")!=null?d.optJSONArray("mats").toString().replace("[","").replace("]","").replace("\"",""):"",
                    "Padrão do disjuntor: "+d.optString("padrao"),
                    "Tamanho box reto: "+d.optString("box"),
                    "",
                    "OBSERVAÇÕES",
                    d.optString("obs"),
                    "",
                    "Assinatura digital do cliente registrada no aplicativo."
                };
                for(String line:lines){
                    if(y>800){pdf.finishPage(p);pi=new PdfDocument.PageInfo.Builder(595,842,pdf.getPages().size()+1).create();p=pdf.startPage(pi);cv=p.getCanvas();y=50;}
                    for(String chunk:wrap(line,80)){cv.drawText(chunk,40,y,paint);y+=17;}
                    y+=3;
                }
                pdf.finishPage(p);
                File dir=new File(c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"OS");
                dir.mkdirs();
                File f=new File(dir,"OS_"+numero+"_"+cliente.replaceAll("[^a-zA-Z0-9áéíóúÁÉÍÓÚçÇ ]","_")+".pdf");
                FileOutputStream out=new FileOutputStream(f);pdf.writeTo(out);out.close();pdf.close();
                Uri uri=FileProvider.getUriForFile(c,c.getPackageName()+".provider",f);
                Intent send=new Intent(Intent.ACTION_SEND);send.setType("application/pdf");send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                c.startActivity(Intent.createChooser(send,"Enviar PDF da OS"));
            }catch(Exception e){Toast.makeText(c,"Erro ao gerar PDF: "+e.getMessage(),Toast.LENGTH_LONG).show();}
        }
        private ArrayList<String> wrap(String s,int n){
            ArrayList<String> a=new ArrayList<>();if(s==null||s.isEmpty()){a.add("");return a;}
            while(s.length()>n){int cut=s.lastIndexOf(" ",n);if(cut<1)cut=n;a.add(s.substring(0,cut));s=s.substring(cut).trim();}a.add(s);return a;
        }
    }
}
